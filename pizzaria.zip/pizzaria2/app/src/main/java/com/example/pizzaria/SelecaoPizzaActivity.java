package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class SelecaoPizzaActivity extends AppCompatActivity {

    private CheckBox checkCalabresa, checkMarguerita, checkPortuguesa;
    private Button btnProximo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_pizza);

        checkCalabresa = findViewById(R.id.checkCalabresa);
        checkMarguerita = findViewById(R.id.checkMarguerita);
        checkPortuguesa = findViewById(R.id.checkPortuguesa);
        btnProximo = findViewById(R.id.btnProximo);

        btnProximo.setOnClickListener(v -> {
            ArrayList<String> pizzasSelecionadas = new ArrayList<>();

            if (checkCalabresa.isChecked()) pizzasSelecionadas.add("Calabresa");
            if (checkMarguerita.isChecked()) pizzasSelecionadas.add("Marguerita");
            if (checkPortuguesa.isChecked()) pizzasSelecionadas.add("Portuguesa");

            if (pizzasSelecionadas.isEmpty()) {
                Toast.makeText(this, "Selecione pelo menos uma pizza", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(this, TamanhoPagamentoActivity.class);
            intent.putStringArrayListExtra("pizzas", pizzasSelecionadas);
            startActivity(intent);
        });
    }
}