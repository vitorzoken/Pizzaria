package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TamanhoPagamentoActivity extends AppCompatActivity {

    private RadioGroup radioGroupTamanho, radioGroupPagamento;
    private Button btnFinalizar;
    private ArrayList<String> pizzasSelecionadas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tamanho_pagamento);

        radioGroupTamanho = findViewById(R.id.radioGroupTamanho);
        radioGroupPagamento = findViewById(R.id.radioGroupPagamento);
        btnFinalizar = findViewById(R.id.btnFinalizar);

        pizzasSelecionadas = getIntent().getStringArrayListExtra("pizzas");

        btnFinalizar.setOnClickListener(v -> {
            int selectedTamanhoId = radioGroupTamanho.getCheckedRadioButtonId();
            int selectedPagamentoId = radioGroupPagamento.getCheckedRadioButtonId();

            if (selectedTamanhoId == -1 || selectedPagamentoId == -1) {
                Toast.makeText(this, "Selecione tamanho e método de pagamento", Toast.LENGTH_SHORT).show();
                return;
            }

            RadioButton radioTamanho = findViewById(selectedTamanhoId);
            RadioButton radioPagamento = findViewById(selectedPagamentoId);

            String tamanho = radioTamanho.getText().toString();
            String pagamento = radioPagamento.getText().toString();

            Intent intent = new Intent(this, ResumoPedidoActivity.class);
            intent.putStringArrayListExtra("pizzas", pizzasSelecionadas);
            intent.putExtra("tamanho", tamanho);
            intent.putExtra("pagamento", pagamento);
            startActivity(intent);
        });
    }
}
