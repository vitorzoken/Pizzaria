package com.example.pizzaria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Locale;

public class ResumoPedidoActivity extends AppCompatActivity {

    private TextView txtResumo, txtValorTotal;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resumo_pedido);

        txtResumo = findViewById(R.id.txtResumo);
        txtValorTotal = findViewById(R.id.txtValorTotal);
        btnVoltar = findViewById(R.id.btnVoltar);

        ArrayList<String> pizzas = getIntent().getStringArrayListExtra("pizzas");
        String tamanho = getIntent().getStringExtra("tamanho");
        String pagamento = getIntent().getStringExtra("pagamento");

        // Calcular valor total
        double valorPizzas = 0;

        for (String pizza : pizzas) {
            if (pizza.equals("Calabresa")) valorPizzas += 25;
            else if (pizza.equals("Marguerita")) valorPizzas += 30;
            else if (pizza.equals("Portuguesa")) valorPizzas += 35;
        }

        double adicionalTamanho = 0;
        if (tamanho.contains("Média")) adicionalTamanho = 10;
        else if (tamanho.contains("Grande")) adicionalTamanho = 20;

        double valorTotal = valorPizzas + adicionalTamanho;

        // Aplicar desconto se for dinheiro
        if (pagamento.contains("Dinheiro")) {
            valorTotal *= 0.95; // 5% de desconto
        }

        // Montar resumo
        StringBuilder resumo = new StringBuilder("Resumo do Pedido:\n\n");
        resumo.append("Pizzas:\n");
        for (String pizza : pizzas) {
            resumo.append("- ").append(pizza).append("\n");
        }
        resumo.append("\nTamanho: ").append(tamanho.split("\\(")[0].trim()).append("\n");
        resumo.append("Pagamento: ").append(pagamento.split("\\(")[0].trim());

        txtResumo.setText(resumo.toString());
        txtValorTotal.setText(String.format(Locale.getDefault(), "Valor Total: R$ %.2f", valorTotal));

        btnVoltar.setOnClickListener(v -> {
            Intent intent = new Intent(this, SelecaoPizzaActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
        });
    }
}
